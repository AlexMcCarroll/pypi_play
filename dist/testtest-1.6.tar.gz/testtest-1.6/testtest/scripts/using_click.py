import click

@click.command()
def cli():
    print("Hello World Again! :fire:")
