from setuptools import setup

setup(
      name='testtest',
      version='1.0',
      description='Testing Framework',
      url='https://github.com/AlexMcCarroll/pypi_play',
      author='Alex McCarroll',
      author_email='alexandra@mccarrollhk.com',
      license='MIT',
      packages=['testtest'],
      zip_safe=False
      )
